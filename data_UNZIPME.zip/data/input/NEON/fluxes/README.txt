The NCAR-NEON product including eddy-covariance fluxes and climatic data used in the analysis can be downloaded from: https://doi.org/10.48443/8w20-r938
Transpiration estimates were calculated via the methodology of Nelson et al. (2018), which can be found at: https://doi.org/10.5281/zenodo.5638851

Coupling Water and Carbon Fluxes to Constrain Estimates of Transpiration: The TEA Algorithm
Jacob A Nelson, Nuno Carvalhais, Matthias Cuntz, Nicolas Delpierre, Jürgen Knauer, Jérome Ogée, Mirco Migliavacca, Markus Reichstein, Martin Jung
Journal of Geophysical Research: Biogeosciences (2018-12) https://doi.org/gfkpng
DOI: 10.1029/2018jg004727