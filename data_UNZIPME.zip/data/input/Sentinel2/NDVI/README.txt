Sentinel-2 NDVI cut-outs used for the analysis can be downloaded from Google Earth Engine using the script at: https://code.earthengine.google.com/c5e4b08a8d0336479bca594279eb04f0
Sentinel-2 cut-outs for all bands used for the analysis can be downloaded from Google Earth Engine using the script at: https://code.earthengine.google.com/9274b8930259730af654e6910fd83bae
